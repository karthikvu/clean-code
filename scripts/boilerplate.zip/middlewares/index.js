const buildMiddlewares = ({ gateways, useCases, logger }) => {
  return [];
};

export { buildMiddlewares };
